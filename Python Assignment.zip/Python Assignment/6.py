(6) Authentication : Ask username, password and compare. 

Ans :  

Code : correct_username = "admin"  

correct_password = "123" 

username = input("Enter username: ") 	 

password = input("Enter password: ") 

               If username == correct_username and password == correct_password:   

print("Login successful!")  

else:  

print("Invalid username or password") 

 

Output : Enter username: admin 

      Enter password: 123 

      Login successful! 

 