(4) Display trigonometric table of sin, cos and tan. 

Ans :  

Code : import math 

print(f"{'Angle':<10}{'Sin':<15}{'Cos':<15}{'Tan':<15}") print("-" * 55) 

for angle in range(0, 361, 30):  

rad = math.radians(angle)  

 sin_val = math.sin(rad)  

cos_val = math.cos(rad)  

tan_val = “undefined” if cos_val==0 else math.tan(rad) 

print(f”{angle:<10}{sin_val:<15.6f}{cos_val:<15.6f}{tan_val:<15}”) 

 

 

 

Output : 

Angle     Sin            Cos            Tan             

------------------------------------------------------- 

0         0.000000       1.000000       0.000000        

30        0.500000       0.866025       0.577350        

60        0.866025       0.500000       1.732051        

90        1.000000       0.000000       undefined       

120       0.866025      -0.500000      -1.732051        

150       0.500000      -0.866025      -0.577350        

180       0.000000      -1.000000       0.000000        

210      -0.500000      -0.866025       0.577350        

240      -0.866025      -0.500000       1.732051        

270      -1.000000       0.000000       undefined       

300      -0.866025       0.500000      -1.732051        

330      -0.500000       0.866025      -0.577350        

360       0.000000       1.000000       0.000000   