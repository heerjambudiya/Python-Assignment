(1) Display the difference in dates from datetime import date. 

Ans :  

Code : from datetime import date 

               d1=date(2025, 5 , 25);  

               d2=date(2004, 5 , 25); 

difference=d1-d2; 

print(“Difference:”, difference.days, “days”); 

 

Output : Difference:7671 days 

 