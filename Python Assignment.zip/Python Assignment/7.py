(7) Authentication : Ask username, password and compare with encryption. 

Ans : 

Code : import hashlib 

def encrypt_password(password): return hashlib.sha256(password.encode()).hexdigest() 

correct_username = "admin"  

correct_password_hash = encrypt_password("12345")  

username = input("Enter username: ")  

password = input("Enter password: ") 

entered_password_hash = encrypt_password(password) 

if username == correct_username and entered_password_hash == correct_password_hash:  

print("Login successful!")  

else:  

print("Invalid username or password") 

 

Output : Enter username: admin 

      Enter password: 12345 

      Login successful! 

       	  Enter username: Heer 

  Enter password: 2704 

  Invalid username or password 