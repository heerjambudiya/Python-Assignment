(5) Generate 10 random numbers. 

Ans :  

Code : import random 

 	print("10 Random Numbers:") 

 	for _ in range(10): 

    	print(random.randint(1, 100))   

 

Output : 

10 Random Numbers: 

 47 

83 

12 

99 

26 

41 

73 

18 

65 

30     

 