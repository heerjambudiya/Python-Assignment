(8) Authentication : Ask username, password and compare with hashing. 

Ans : 

Code :  

import hashlib  

correct_username = "admin1" 

 stored_password_hash = hashlib.sha256("2502".encode()).hexdigest() username = input("Enter username: ")  

password = input("Enter password: ") 

 entered_password_hash = hashlib.sha256(password.encode()).hexdigest() 

 if username == correct_username and entered_password_hash == stored_ password _ hash:  

print("Login successful! Welcome,", username)  

else:  

print("Invalid username or password!") 

 

Output : Enter username : admin1 

      Enter password : 2502 

      Login successful! Welcome, admin1 

 