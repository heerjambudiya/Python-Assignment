(3) Display your age in years, months and days. 

Ans :  

Code : from datetime import date 

birthdate=date(2004, 5, 25) 

today=date.today() 

difference=today-birthdate; 

years=diff.days // 365  

months=(diff.days % 365 ) // 30  

days=(diff.days % 365) % 30 

print(f‘Difference in Year: {years}, Months: {months} ,Days: {days} ') 

 

Output : Difference in Year: 20, Months: 4 ,Days: 26 

 