(10) Code for string manipulation : 

1. Calculate the length of a string without using len().  

Ans :   def string_length(s): 

 count = 0  

  for _ in s:  

  count += 1  

return count  

   print("1.", string_length("HelloWorld"))  

Output:  

10  

2. Count occurrences of a substring.  

Ans : def count_substring(s, sub):  

return s.count(sub)  

print("2.", count_substring("banana", "na"))  

Output: 

 2  

3. Create a string made of first, middle and last character. 

Ans : def first_middle_last(s):  

mid = len(s) 	 

return s[0] + s[mid] + s[-1]  

print("3.", first_middle_last("programming")) 

Output: 

 "png"  

4. Create a string made of middle three characters. 

Ans :  def middle_three(s):  

mid = len(s)  

return s[mid-1:mid+2]  

print("4.", middle_three("computer"))  

Output: 

 "put"  

5. Insert one string into the middle of another string. 

Ans : def insert_middle(s1, s2):  

mid = len(s1)  

 return s1[:mid] + s2 + s1[mid:]  

print("5.", insert_middle("python", "JAVA")) 

Output:  

"pyJAVAthon"  

6. Create a string made of first, last and middle characters of two strings. 

Ans : def mix_strings(s1, s2):  

return s1[0] + s2[0] + s1[len(s1)//2] + s2[len(s2)//2] + s1[-1] + s2[-1] 	print("6.", mix_strings("America", "Japan")) 

Output:  

"AJrpan"  

7. Arrange string characters such that lowercase letters should come first. 

Ans : def arrange_lowercase_first(s): 

 lower = "".join([c for c in s if c.islower()]) 	 

 upper = "".join([c for c in s if c.isupper()])  

 return lower + upper print("7.", arrange_lowercase_first("PyNaTive"))  

Output:  

"yaivePNT"  

8. Count all letters, digits, and special symbols. 

Ans : def count_types(s): 

letters = sum(c.isalpha() for c in s)  

digits = sum(c.isdigit() for c in s)  

symbols = len(s) - letters - digits return letters, digits, symbols  

print("8.", count_types("P@ssw0rd123")) 

Output:  

(6 letters, 3 digits, 2 symbols)  

9. Find all occurrences of “USA” in a given string ignoring case. 

Ans : def find_usa(s):  

return s.lower().count("usa")  

print("9.", find_usa("USA is different from usa and UsA."))  

Output: 

 3  

10. Given a string, return the sum and average of the digits that appear in it. 

Ans : def sum_and_average(s):  

digits = [int(c) for c in s if c.isdigit()]  

total = sum(digits)  

avg = total / len(digits) if digits else 0  

return total, avg print("10.", sum_and_average("PY123THON9"))  

Output:  

(15, 3.75)  

11. Reverse a given string. 

Ans : def reverse_string(s):  

return s[::-1]  

print("11.", reverse_string("Python"))  

Output:  

"nohtyP" 

 

 
 

 