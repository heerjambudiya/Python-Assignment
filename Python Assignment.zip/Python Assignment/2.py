(2) Display time since epoch in hours and minutes. 

Ans : 

Code : import time 

t1=int(time.time())  

hours=t1//3600  

min=(t1 % 3600)//60  

print("Time since epoch:")  

print('{hours} hours and {min} minutes') 

 

Output : Time since epoch: 488296 hours and 5 minutes 

 