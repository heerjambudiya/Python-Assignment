(9) Convert string “Hello$World” into Base64 

Ans : 

Code : 

import base64 

 text = "Hello$World" 

 encoded = base64.b64encode(text.encode()) 

 print("Original String:", text) 

print("Base64 Encoded:", encoded.decode()) 

Output :  

Original String: Hello$World 

Base64 Encoded: SGVsbG8kV29ybGQ= 

 